"use strict";

module.exports = {
  cloudfunctions: require("./cloudfunctions"),
  cloudlogging: require("./cloudlogging"),
  storage: require("./storage"),
  rules: require("./rules"),
};
