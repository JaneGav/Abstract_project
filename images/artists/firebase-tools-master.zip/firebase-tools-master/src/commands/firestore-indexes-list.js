"use strict";

var Command = require("../command");
var firestoreIndexes = require("../firestore/indexes.js");
var requirePermissions = require("../requirePermissions");
var logger = require("../logger");
var _ = require("lodash");

var _prettyPrint = function(indexes) {
  indexes.forEach(function(index) {
    logger.info(firestoreIndexes.toPrettyString(index));
  });
};

var _makeJsonSpec = function(indexes) {
  return {
    indexes: indexes.map(function(index) {
      return _.pick(index, ["collectionId", "fields"]);
    }),
  };
};

module.exports = new Command("firestore:indexes")
  .description("List indexes in your project's Cloud Firestore database.")
  .option(
    "--pretty",
    "Pretty print. When not specified the indexes are printed in the " +
      "JSON specification format."
  )
  .before(requirePermissions, ["datastore.indexes.list"])
  .action(function(options) {
    return firestoreIndexes.list(options.project).then(function(indexes) {
      var jsonSpec = _makeJsonSpec(indexes);

      if (options.pretty) {
        _prettyPrint(indexes);
      } else {
        logger.info(JSON.stringify(jsonSpec, undefined, 2));
      }

      return jsonSpec;
    });
  });
